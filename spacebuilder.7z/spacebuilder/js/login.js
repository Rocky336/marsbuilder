/*************************************************/
/*            FUNZIONI DI NAVIGAZIONE            */
/*************************************************/

function goToGoogle(){
    window.location = "https://www.google.com";
}

/*************************************************/
/*           FUNZIONI DI REGISTRAZIONE           */
/*************************************************/

function checkPassword(){
    return document.getElementById("r-password").value==document.getElementById("r-cpassword").value;
}

async function register(){
    if(!checkPassword()){
        alert("Le password non combaciano");
        return;
    }
    let data = {
        id: -1,
        email: document.getElementById("r-email").value,
        nickname: document.getElementById("r-nickname").value,
        avatar: "",
        password: document.getElementById("r-password").value
    };

    let formData = new FormData();
    formData.append("data",JSON.stringify(data));

    let result = await fetch("./api/register.php",{
        method: "POST",
        body: formData
    });

    result = await result.json();

    if(result.code==1){
        alert(result.description);
        window.location.reload();
    }else{
        alert("errore salvataggio: "+result.description);
    }
}

async function login(){
    let data = {
        email: document.getElementById("l-email").value,
        password: document.getElementById("l-password").value
    };
    let formData = new FormData();
    formData.append("data",JSON.stringify(data));

    let result = await fetch("./api/login.php",{
        method: "POST",
        body: formData
    });

    result = await result.json();

    if(result.code==1){
        alert(result.description);
    }else{
        alert("errore salvataggio: "+result.description);
    }
}