import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {HUD} from './hud.js'

let renderer = null;      // Il motore di render

let scene = null;         // la scena radice
let camera = null;        // la camera da cui renderizzare la scena
let audiolistener = null; // L'oggetto per sentire i suoni del gioco
let clock = null;         // Oggetto per la gestione del timinig della scena

let jsonMap = fetch("./api/load_map.php");

/**
 * L'array delle mesh delle pedine che costituiscono la board
 */
let meshBoard = [];

/**
 * Il set dei valori che rappresentano la board
 */
let board = [];

/**
 * Luce direzionale, al momento non è utile
 */
let dl = null;

/**
 * Canvas
 */
let canv = null;

/**
 * Mouse coordinates
 */
const mousePointer = new THREE.Vector2();

/**
 * Raycaster
 */
const raycaster = new THREE.Raycaster();
raycaster.far = 1000;
raycaster.near = 0.1;

/**
 * Blocks and rocks
 */
const blocks = new THREE.Group();
const rocks = new THREE.Group();
const edifici = new THREE.Group();

/**
 * Blocco evidenziato e modello selezionato
 */
let selected_block = null;;
let selected_model = null;
let choosing_model = null;

let edifici_id = null;
let loaded_assets = {};
let fans = [];

/**
 * Loader
 */
let loader = new GLTFLoader();

/**
 * HUD
 */
let hud = null;

/*
 * Inizializza il motore
 */ 
function initScene(){
  if (renderer != null) return;

  window.addEventListener("mousemove",mouseMoved);
  canv = document.getElementById("threejs");
  
  document.getElementById("start").style.display="none";
  document.getElementById("sign-in").style.display="none";
  canv.style.display="block";
  
  let width = canv.clientWidth;
  let height = canv.clientHeight;

  renderer = new THREE.WebGLRenderer({antialias: "true", powerPreference: "high-performance", canvas: canv});
  renderer.autoClear = false;
  renderer.setSize(width, height);
  renderer.setClearColor("black", 1);
  renderer.shadowMap.enabled = true;

  camera = new THREE.PerspectiveCamera(50, width/height, 0.1, 500);
  camera.position.set(4.5, 4.80, 0);
  camera.lookAt(4.5, 0, 4.5);

  hud = new HUD(width,height);

  audiolistener = new THREE.AudioListener();
  camera.add(audiolistener);

  clock = new THREE.Clock();

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0xd36c06);

  dl = new THREE.DirectionalLight(0xFFFFFF, 1);
  scene.add(dl);

  fetchAndLoad();

  renderer.setAnimationLoop(animate);
}

/**
 * Fetch assets and load city
 */
async function fetchAndLoad(){
  edifici_id = (await (await fetch("./api/fetch_assets.php")).json());
  let keys = Object.keys(edifici_id);
  for(const key in edifici_id){
    loader.load("./assets/space_bits/gltf/"+edifici_id[key],(gltf)=>{
      loaded_assets[key] = gltf.scene.children[0];
      if(key==keys[keys.length-1]){
        //Create board
        createBoard();

        //Load HUD;
        hud.assetSelector(loaded_assets);
        hud.translate(1);

        //Load city
        loadCity();
      }
    })
  }
}

async function loadCity(){
  let json = await fetch("./api/buildingscity.php");
  let res = await json.json();
  if(!res) return;
  res.forEach((array)=>{
    let edificio = loaded_assets[array.id_edificio].clone();
    edificio.original_mat = edificio.material.clone();
    edificio.second_mat = edificio.material.clone();
    edificio.model_id = array.id_edificio;
    edificio.position.set(Math.floor(array.posizione/100)*2,0,2*array.posizione%100);
    if(array.id_edificio==56||array.id_edificio==57){
      fans.push(edificio.children[0]);
    }
    edifici.add(edificio);
  })
}

/**
 * Crea la board di gioco
 * @param {Number} max Il numero di elementi complessivi della board; deve essere un numero divisibile per 4
 * @param {Number} size Le dimensioni della geometria 
 */

async function createBoard(){
  let map = JSON.parse(await (await jsonMap).text());
  
  meshBoard = new Array();
  for(let i = 0; i < map.row; i++){
    meshBoard[i] = new Array();
    for(let j = 0; j < map.col; j++){
      let id = 42;
      switch (map.data[i][j].cat) {
        case 1:
          id = 42;
          break;
        case 2:
          id = 43;
          break;
        case 3:
          id = 45;
          break;
        case 4:
          id = 47;
          break;
        case 5:
          id = 46;
          break;
        default:
          break;
      }
        
      meshBoard[i][j] = loaded_assets[id].clone();
      meshBoard[i][j].position.set(j*2, 0, i*2);
      meshBoard[i][j].rotateY(Math.PI*0.5*map.data[i][j].rot);
      meshBoard[i][j].row = i;
      meshBoard[i][j].col = j;
      meshBoard[i][j].original_mat = meshBoard[i][j].material.clone();
      meshBoard[i][j].second_mat = meshBoard[i][j].material.clone();
      blocks.add(meshBoard[i][j]);
    }
  }

  scene.add(blocks);
  scene.add(rocks);
  scene.add(edifici);
  dl.position.set((map.col*2*0.5) + 80, 80, (map.row*2*0.5) + 0);
  camera.position.set((map.col*2*0.5) + 15, 20, (map.row*2*0.5) + 15);
  camera.lookAt((map.col*2*0.5), 0, (map.row*2*0.5));
}

/**
 * Anima la scena e la renderizza
 */
function animate(){
    let dt = clock.getDelta();

    for(let i in fans){
      fans[i].rotateZ(dt*Math.PI*.5)
    }
    
    renderer.clear();
    renderer.render(scene, camera);
    renderer.render(hud.scene,hud.camera);
}

function mouseMoved(event){
  mousePointer.x = ( event.clientX / window.innerWidth ) * 2 - 1;
  mousePointer.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
  
  raycaster.setFromCamera(mousePointer,hud.camera);
  const hud_intersects = raycaster.intersectObjects(hud.scene.children);
  if(hud_intersects.length>0){
    choosing_model = hud.getId(hud_intersects[0].object);
    hud.changeColor(choosing_model,false,0x00ff00);
  }else{
    if(choosing_model!=null)
      hud.changeColor(choosing_model,true);
    choosing_model = null;
    raycaster.setFromCamera(mousePointer,camera);
    let intersects;
    if(selected_model!=null){
      intersects = raycaster.intersectObjects(blocks.children);
    }else{
      intersects = raycaster.intersectObjects(blocks.children.concat(edifici.children));
    }
    if(selected_block!=null&&selected_block.object.original_mat!=null){
      selected_block.object.material = selected_block.object.original_mat;
    }
    selected_block = intersects[0];
    if(selected_block!=null&&selected_block.object.second_mat!=null){
      selected_block.object.second_mat.color.set(selected_model==null?0xff0000:0x00ff00);
      selected_block.object.material = selected_block.object.second_mat;
    }
    if(selected_model!=null&&selected_block!=null){
      selected_model.position.set(selected_block.object.col*2,0,selected_block.object.row*2);
    }
  }
}

function mouseClick(event){
  if(selected_model!=null&&selected_block==null){
    edifici.remove(selected_model);
    selected_model = null;
  }
  if(choosing_model!=null){
    hud.changeColor(choosing_model,true);
    if(selected_model) edifici.remove(selected_model);
    selected_model = loaded_assets[choosing_model].clone();
    selected_model.original_mat = selected_model.material.clone();
    selected_model.second_mat = selected_model.material.clone();
    edifici.add(selected_model);
    selected_model.model_id = choosing_model;
    choosing_model = null;
  }else if(selected_block){
    if(selected_model){
      let data = {
        model_id: selected_model.model_id,
        method: "ADD",
        pos: selected_block.object.col*100+selected_block.object.row
      };
      let formData = new FormData();
      formData.append("data",JSON.stringify(data));

      fetch("./api/buildingscity.php",{
        method: "POST",
        body: formData
      }).then(raw => raw.json().then(res => {
        if(res.code==1){
          if(data.model_id==56||data.model_id==57)
            fans.push(selected_model.children[0]);
          selected_model = loaded_assets[data.model_id].clone();       
          selected_model.model_id = data.model_id;   
          selected_model.original_mat = selected_model.material.clone();
          selected_model.second_mat = selected_model.material.clone();
          edifici.add(selected_model);
        }
      }))

    }else if(selected_block.object.parent == edifici){
      let obj = selected_block.object
      let data = {
        model_id: obj.model_id,
        method: "REMOVE",
        pos: Math.floor(obj.position.x*50)+Math.floor(obj.position.z*.5)
      };
      let formData = new FormData();
      formData.append("data",JSON.stringify(data));

      fetch("./api/buildingscity.php",{
        method: "POST",
        body: formData
      }).then(raw => raw.json().then(res => {
        if(res.code==1)
          edifici.remove(obj);
      }))
    }
  }
}

async function loadPlayer(){
  let playerData = await (await fetch("./api/player_get.php")).json();
  if(playerData.player!=undefined){
    let el = document.getElementById("sign-in")
    el.innerHTML = "";
    el.innerHTML = "Welcome "+playerData.player.nickname;
  }
};

async function login(e,p){
  let data = {
      email: e,
      password: p
  };
  let formData = new FormData();
  formData.append("data",JSON.stringify(data));

  let result = await fetch("./api/login.php",{
      method: "POST",
      body: formData
  });

  result = await result.json();

  if(result.code==1){
    window.location.reload();
  }
}

async function register(e,p,n){
  let data = {
    email: e,
    password: p,
    nickname: n,
    avatar: '',
    id: -1
  };
  let formData = new FormData();
  formData.append("data",JSON.stringify(data));

  let result = await fetch("./api/register.php",{
      method: "POST",
      body: formData
  });

  result = await result.json();

  if(result.code==1){
    login(e,p);
  }
}

let email =null;
let password =null;

async function email_exists(e,p){
  let data = {
    email: e,
  };
  let formData = new FormData();
  formData.append("data",JSON.stringify(data));

  let result = await fetch("./api/login.php",{
    method: "POST",
    body: formData
  });
  result = await result.json();
  
  if(result.email_exists == "0"){
    password = p;
  }else{
    login(e,p);
  }
}

function loginStep(){
  let val = document.getElementById("login-input").value;
  if(email==null){
    email = val;
    document.getElementById("sign-label").innerText = "PASSWORD";
    document.getElementById("login-input").value = "";
  }else if(password==null){
    email_exists(email,val);
    document.getElementById("sign-label").innerText = "NICKNAME";
    document.getElementById("login-input").value = "";
  }else{
    register(email,password,val);
  }
}

window.addEventListener("click",(event)=>{
  event.preventDefault();
  if(event.target==document.getElementById("start")) initScene();
  else if(event.target==document.getElementById("login-next")) loginStep();
  else if(renderer!=null) mouseClick(event);
})

window.addEventListener("keydown",(event)=>{
  if(event.key=='r'&&selected_model!=null) selected_model.rotateY(Math.PI*.5);
  else if(event.key=='Enter'&&event.target==document.getElementById("login-input")) loginStep();
})

window.addEventListener("resize",()=>{
  let width = window.innerWidth;
  let height = window.innerHeight;
  if(hud!=null){
    hud.resize(width,height)
  }
  if(camera!=null){
    camera.aspect = width/height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
  }
})

window.addEventListener("wheel",(event)=>{
  if(hud!=null){
    hud.translate(Math.sign(event.deltaY));
  }
})

loadPlayer();