import * as THREE from 'three';

export class HUD{
    
    constructor(width,height){
        this.scene = new THREE.Scene();
        this.camera = new THREE.OrthographicCamera(width / -2, width/2, height/2, height/-2,1,1000);
        this.light = new THREE.AmbientLight(new THREE.Color(0xFFFFFF),3);
        this.scene.add(this.camera);
        this.scene.add(this.light);
        this.width = width;
        this.height = height;
        this.assets = {};
        this.translation = 0;

        this.context = document.createElement('canvas').getContext('2d');
        this.context.canvas.width = 300;
        this.context.canvas.height = 100;
        this.context.fillStyle = '#ff';
        this.context.font = '100px Arial'
        this.context.fillRect( 0, 0, this.context.canvas.width, this.context.canvas.height );
        this.ctx_texture = new THREE.CanvasTexture(this.context.canvas);

        this.plane = new THREE.Mesh(new THREE.PlaneGeometry(300,100),new THREE.MeshBasicMaterial( {
            map: this.ctx_texture,
        } ));

        this.plane.position.set(-width/2+150,height/2-50,-50);

        //this.scene.add(this.plane);
    }

    setText(text){
        this.context.fillStyle = '#ff';
        this.context.fillRect( 0, 0, this.context.canvas.width, this.context.canvas.height );
        this.context.fillStyle = '#ffffff';
        this.context.fillText(text,10,85);
        
        this.ctx_texture.needsUpdate = true;
    }

    assetSelector(assets){
        let asset;
        for(let key in assets){
            asset = assets[key].clone();
            asset.original_mat = asset.material.clone();
            asset.second_mat = asset.material.clone();
            asset.position.set(this.assets.length*100-.5*this.width,-this.height/2+30,-50);
            asset.scale.set(40,40,40);
            asset.model_id = key;
            this.assets[key]=asset;
            this.scene.add(asset);
        }

        this.camera.lookAt(new THREE.Vector3(0,0,-1));
    }

    changeColor(id,original,color){
        if(original){
            this.assets[id].material = this.assets[id].original_mat;
        }else{
            this.assets[id].second_mat.color.set(color);
            this.assets[id].material = this.assets[id].second_mat;
        }
    }

    resize(width,height){
        this.camera.top = height/2;
        this.camera.bottom = -height/2;
        this.camera.left = -width/2;
        this.camera.right = width/2;
        this.camera.updateProjectionMatrix();
        this.width = width;
        this.height = height;
        this.plane.position.set(-width/2+150,height/2-50,-50);
        for(let i in this.assets)
            this.assets[i].position.set(i*100-.5*width+this.translation,-height/2+30,-50);
    }

    translate(translation){
        this.translation -= translation*50;
        for(let i in this.assets)
            this.assets[i].position.set(i*100-.5*this.width+this.translation,-this.height/2+30,-50);
    }

    getId(obj){
        if(obj==null) return null;
        if(obj.parent==this.scene) return obj.model_id;
        return this.getId(obj.parent);
    }
};
