<?php
    header('Content-Type: application/json;charset=utf-8');

    require_once(__DIR__.'/model/giocatore.php');
    require_once(__DIR__.'/model/citta.php');

    if(array_key_exists("data",$_POST)){
        $giocatore = Giocatore::createFromJSON($_POST["data"]);

        if($giocatore->save()){
            Citta::createNewCity($giocatore->id);

            echo '{"code":1, "description": "giocatore salvato"}';
        }else{
            echo '{"code":0, "description": "wrong data"}';
        }
    }else{
        echo '{"code":0, "description": "no data"}';
    }
?>