<?php
session_start();

header('Content-Type: application/json; charset=utf-8');

require_once(__DIR__."/model/giocatore.php");
require_once(__DIR__ . "/model/citta.php");

if(array_key_exists("data",$_POST)){
    $login = json_decode($_POST["data"]);
    if(property_exists($login,"password")){
        $giocatore = Giocatore::login($login->email,$login->password);
        if($giocatore==null){
            echo '{"code":0,"description":"utente non esiste"}';
        }else{
            $_SESSION["giocatore"] = $giocatore;

            $c = Citta::loadFromPlayer($giocatore->id);
            if($c == null){
                echo '{"code":0,"description":"errore caricamento città"}';
            }else{
                $_SESSION['citta'] = $c;
                echo '{"code":1,"description":"login effettuato"}';
            }
        }
    }else{
        echo '{"email_exists": "'.Giocatore::email_exists($login->email).'"}';
    }
}   
?>