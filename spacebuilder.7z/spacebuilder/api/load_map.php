<?php
header('Content-Type: application/json;charset=utf-8');
echo('{"row": 10, "col": 10, "data": ['.
        '[{"cat": 5, "rot":1}, {"cat": 3, "rot":1}, {"cat": 3, "rot":1}, {"cat": 3, "rot":1}, {"cat": 3, "rot":1}, {"cat": 3, "rot":1}, {"cat": 3, "rot":1}, {"cat": 3, "rot":1}, {"cat": 3, "rot":1}, {"cat": 4, "rot":1}],' .
        '[{"cat": 3, "rot":2}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}],' .
        '[{"cat": 3, "rot":2}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}],' .
        '[{"cat": 3, "rot":2}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}],' .
        '[{"cat": 3, "rot":2}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}],' .
        '[{"cat": 3, "rot":2}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}],' .
        '[{"cat": 3, "rot":2}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}],' .
        '[{"cat": 3, "rot":2}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}],' .
        '[{"cat": 3, "rot":2}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}],' .
        '[{"cat": 4, "rot":1}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 1, "rot":0}, {"cat": 2, "rot":1}]' .
    ']}');
?>