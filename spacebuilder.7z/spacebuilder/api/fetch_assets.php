<?php
header('Content-Type: application/json;charset=utf-8');
/*
$cartella = "./../assets/space_bits/gltf";
$files = scandir($cartella);
$json = '[';

foreach($files as $file){
    if ($file !== '.' && $file !== '..') {
        if (is_file($cartella . '/' . $file) && pathinfo($cartella . '/' . $file, PATHINFO_EXTENSION)=='gltf') {
            $json .= '"'.$file . '",';
        }
    }
}

$json = rtrim($json, ",");
$json .= ']';
*/

require_once(__DIR__ . "/model/utils.php");

$conn = dbConnect();
$query = "SELECT id_edificio,src_modello FROM `edifici` ORDER BY id_edificio ASC";
$res = $conn->query($query);

$json = '{';

while( $row = $res->fetch_array() )
{
    $json .= '"'.$row["id_edificio"].'":"'.$row["src_modello"] . '",';
}
$json = rtrim($json, ",");
$json .= '}';

echo $json;

?>