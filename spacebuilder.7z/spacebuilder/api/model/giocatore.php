<?php
require_once(__DIR__."/utils.php");

class Giocatore{
    var $id;
    var $nickname;
    var $email;
    var $avatar;
    var $password;

    public function __construct(){
        $this->id = -1;
        $this->nickname;
        $this->email;
        $this->avatar;
        $this->password;
    }
    
    public function save(){
        $conn = dbConnect();
        $query = "";

        if($this->id==-1){
            $query = "INSERT INTO giocatori VALUES(null, " . 
                     "'" . $this->nickname . "', " .
                     "AES_ENCRYPT('" . $this->email . "','1234')," .
                     "'" . $this->avatar . "', " .
                     "AES_ENCRYPT('" . $this->password . "','1234'))";
        }else{
            $query = "UPDATE giocatori SET " .
                     "avatar = '" . $this->avatar . "', ".
                     "password = '" . $this->password . "' ".
                     "WHERE id=".$this->id;
        }

        $res = $conn->query($query);
        if($res){
            $this->id = mysqli_insert_id($conn);
        }
        return $res;
    }

    public static function createFromJSON($json){
        $g = new Giocatore();
        $data = json_decode($json);

        $g->id = $data->id;
        $g->nickname = $data->nickname;
        $g->email = $data->email;
        $g->password = $data->password;
        $g->avatar = $data->avatar;

        return $g;
    }

    public static function login($email,$password){        
        $conn = dbConnect();
        $query = "  SELECT id_giocatore,nickname,avatar FROM giocatori 
                    WHERE email=AES_ENCRYPT('$email','1234')
                    AND password=AES_ENCRYPT('$password','1234')";
        $res = $conn->query($query);

        if($res->num_rows==0){
            return null;
        }
        $row = $res->fetch_assoc();
        $giocatore = new Giocatore();
        $giocatore->id = $row["id_giocatore"];
        $giocatore->nickname = $row["nickname"];
        $giocatore->avatar = $row["avatar"];
        $giocatore->email = $email;
        return $giocatore;
    }

    public static function email_exists($email){
        $conn = dbConnect();
        $query = "  SELECT id_giocatore FROM giocatori 
                    WHERE email=AES_ENCRYPT('$email','1234')";
        $res = $conn->query($query);

        return $res->num_rows;
    }
}
?>