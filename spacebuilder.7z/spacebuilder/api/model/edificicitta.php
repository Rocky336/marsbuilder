<?php
require_once(__DIR__."/utils.php");

class EdificiCitta{
    public static function loadEdifici($id){
        $conn = dbConnect();
        $query = "  SELECT * FROM edifici_citta 
                    WHERE id_citta=$id";
        $res = $conn->query($query);
        
        if($res->num_rows==0){
            return null;
        }
        $edifici = array();
        while($row = $res->fetch_assoc()){
            array_push($edifici,$row);
        }
        return $edifici;
    }

    public static function editEdificio($method,$id_citta,$id_edificio,$posizione){
        $conn = dbConnect();
        $query = "SELECT id_risorsa,qta FROM risorse_citta WHERE id_citta=$id_citta";
        $risorse = $conn->query($query);
        $result1 = [];
        while($row = $risorse->fetch_assoc()){
            $result1[$row["id_risorsa"]] = $row["qta"];
        }

        if($method=="ADD"){
            $risorse2 = $conn->query("SELECT id_risorsa,qta FROM edificio_consuma WHERE id_edificio=$id_edificio");
            $result2 = [];
            while($row = $risorse2->fetch_assoc()){
                if($result1[$row["id_risorsa"]]-$row["qta"]<0){
                    return 0;
                }
                $result2[$row["id_risorsa"]] = $row["qta"];
            }
            
            foreach($result2 as $x => $y){
                $quantity = $result1[$x]-$result2[$x];
                $conn->query("UPDATE risorse_citta SET qta=$quantity WHERE id_risorsa=$x AND id_citta=$id_citta");
            }

            $query = "INSERT INTO edifici_citta VALUES(".$id_citta.",".$id_edificio.",0,".$posizione.",0)";
        }elseif($method=="REMOVE"){
            $query = "DELETE FROM edifici_citta WHERE id_citta=".$id_citta." AND id_edificio=".$id_edificio." AND posizione=".$posizione;
        }
        $res = $conn->query($query);
        if($res){
            return 1;
        }
        return 0;
    }
}

?>