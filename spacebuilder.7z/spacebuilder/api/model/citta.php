<?php

require_once(__DIR__ . "/utils.php");

class Citta{
    var $id;
    var $nome;
    var $proprietario;

    public function __construct(){
        $this->id = -1;
        $this->proprietario;
        $this->nome;
    }

    static function createNewCity($pid){
        $conn = dbConnect();
        $query = "INSERT INTO citta VALUES(null,$pid,'Base Marziana')";
        $res = $conn->query($query);

        $c = new Citta();
        $c->id = mysqli_insert_id($conn);
        $c->nome = "Base Marziana";
        $c->proprietario = $pid;

        $conn->query("INSERT INTO risorse_citta VALUES($c->id,1,100)");
        $conn->query("INSERT INTO risorse_citta VALUES($c->id,2,100)");

        return $c;
    }

    static function loadFromPlayer($pid){
        $conn = dbConnect();
        $query = "SELECT * FROM citta WHERE id_giocatore=$pid";
        
        $res = $conn->query($query);
        
        if($res->num_rows==0){
            return null;
        }

        $row = $res->fetch_assoc();

        $citta = new Citta();
        $citta->id = $row["id_citta"];
        $citta->proprietario = $row["id_giocatore"];
        $citta->nome = $row["nome"];
        return $citta;
    }
}