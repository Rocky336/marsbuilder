<?php
/**
 */
function dbConnect(){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "citybuilder";

    $conn = new mysqli($servername,$username,$password,$database);

    if ($conn->connect_errno){
        die("Connection failed" . $conn->connect_error);
    }

    return $conn;
}
?>