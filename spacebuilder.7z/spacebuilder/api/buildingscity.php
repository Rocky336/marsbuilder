<?php
require_once(__DIR__ . "/model/edificicitta.php");
session_start();

header('Content-Type: application/json;charset=utf-8');

if(!array_key_exists("giocatore",$_SESSION)){
    echo '{"code":0,"desc":"Sessione inesistente"';
    exit();
}

$id_citta = json_decode(json_encode($_SESSION['citta']))->id;

if($_SERVER['REQUEST_METHOD']=='GET'){
    $buildings = EdificiCitta::loadEdifici($id_citta);
    echo json_encode($buildings);
}elseif($_SERVER['REQUEST_METHOD']=='POST'){
    $dati = json_decode($_POST["data"]);
    $code = EdificiCitta::editEdificio($dati->method,$id_citta, $dati->model_id, $dati->pos);
    echo '{"code":'.$code.'}';
}
?>