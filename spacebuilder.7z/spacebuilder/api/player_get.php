<?php
session_start();

header('Content-Type: application/json; charset=utf-8');

if(array_key_exists("giocatore",$_SESSION)){
    echo '{"player":'.json_encode($_SESSION["giocatore"]).'}';
}else{
    echo '{}';
}